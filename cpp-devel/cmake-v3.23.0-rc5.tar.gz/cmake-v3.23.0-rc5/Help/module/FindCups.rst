.. cmake-module:: ../../Modules/FindCups.cmake
